from errors import(
    wGenericError,
)