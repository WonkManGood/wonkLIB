"""
Microcontroller use only.
"""