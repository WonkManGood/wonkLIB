from setuptools import (
    setup,
    find_packages,
)

setup(
    name='wonkLIB',
    version='1.0',
    packages=find_packages(),
)